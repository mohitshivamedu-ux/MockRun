"use client";

import { useMemo, useState } from "react";
import { getExamById } from "@/lib/exams";
import { formatTime, useTestStore } from "@/lib/test-store";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle2,
  Home,
  RefreshCw,
  Share2,
  Target,
  Timer,
  TrendingUp,
  Trophy,
  XCircle,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function ResultView() {
  const activeMockTest = useTestStore((s) => s.activeMockTest);
  const activeExamId = useTestStore((s) => s.activeExamId);
  const questionStates = useTestStore((s) => s.questionStates);
  const snapshot = useTestStore((s) => s.resultSnapshot);
  const navigate = useTestStore((s) => s.navigate);
  const resetTest = useTestStore((s) => s.resetTest);
  const [filter, setFilter] = useState<"all" | "correct" | "incorrect" | "unattempted">("all");

  const exam = activeExamId ? getExamById(activeExamId) : null;

  const questionAnalysis = useMemo(() => {
    if (!activeMockTest) return [];
    return activeMockTest.questions.map((q, idx) => {
      const st = questionStates[q.id];
      const userSel = st?.selectedOptions ?? [];
      const isAttempted = userSel.length > 0;
      const correctSet = new Set(q.correctOptions);
      const userSet = new Set(userSel);
      const isCorrect =
        isAttempted &&
        correctSet.size === userSet.size &&
        [...correctSet].every((o) => userSet.has(o));
      return { ...q, idx, userSel, isAttempted, isCorrect };
    });
  }, [activeMockTest, questionStates]);

  const filtered = questionAnalysis.filter((q) => {
    if (filter === "all") return true;
    if (filter === "correct") return q.isCorrect;
    if (filter === "incorrect") return q.isAttempted && !q.isCorrect;
    if (filter === "unattempted") return !q.isAttempted;
    return true;
  });

  const perQuestionMark = activeMockTest ? activeMockTest.totalMarks / activeMockTest.totalQuestions : 0;

  // Section-wise breakdown
  const sectionBreakdown = useMemo(() => {
    if (!activeMockTest) return [];
    const map = new Map<string, { total: number; correct: number; incorrect: number; unattempted: number; marks: number }>();
    questionAnalysis.forEach((q) => {
      const entry = map.get(q.section) ?? { total: 0, correct: 0, incorrect: 0, unattempted: 0, marks: 0 };
      entry.total += 1;
      if (!q.isAttempted) entry.unattempted += 1;
      else if (q.isCorrect) {
        entry.correct += 1;
        entry.marks += perQuestionMark;
      } else {
        entry.incorrect += 1;
        entry.marks -= activeMockTest.negativeMarking;
      }
      map.set(q.section, entry);
    });
    return Array.from(map.entries());
  }, [questionAnalysis, perQuestionMark, activeMockTest]);

  if (!activeMockTest || !snapshot) return null;

  const percentage = Math.round((snapshot.marksObtained / snapshot.totalMarks) * 1000) / 10;
  const isPass = snapshot.accuracy >= 50;
  const timeTakenStr = formatTime(snapshot.timeTakenMs);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Result banner */}
      <section className={`text-white ${isPass ? "bg-gradient-to-br from-emerald-600 to-teal-700" : "bg-gradient-to-br from-rose-600 to-orange-700"}`}>
        <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8 lg:py-12">
          <div className="flex flex-col items-center text-center">
            <div className={`mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm`}>
              <Trophy className="h-9 w-9" />
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
              {isPass ? "Great job!" : "Keep practising!"}
            </h1>
            <p className="mt-2 text-sm text-white/85 sm:text-base">
              {activeMockTest.name} · {exam?.name}
            </p>
            <div className="mt-6 grid w-full max-w-3xl grid-cols-2 gap-3 sm:grid-cols-4">
              <BigStat label="Score" value={`${snapshot.marksObtained}`} subValue={`/ ${snapshot.totalMarks}`} />
              <BigStat label="Percentage" value={`${percentage}%`} subValue={isPass ? "Above 50%" : "Below 50%"} />
              <BigStat label="Accuracy" value={`${snapshot.accuracy}%`} subValue={`${snapshot.correct}/${snapshot.attempted} correct`} />
              <BigStat label="Time Taken" value={timeTakenStr} subValue={`of ${activeMockTest.durationMinutes} min`} />
            </div>
          </div>
        </div>
      </section>

      {/* Action buttons */}
      <section className="mx-auto -mt-6 max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white p-3 shadow-md">
          <Button variant="outline" onClick={() => navigate("home")} className="text-xs sm:text-sm">
            <Home className="mr-1 h-4 w-4" /> Home
          </Button>
          <Button variant="outline" onClick={() => navigate("exam", { examId: activeExamId ?? undefined })} className="text-xs sm:text-sm">
            <RefreshCw className="mr-1 h-4 w-4" /> Try Another Mock
          </Button>
          <Button variant="default" onClick={() => resetTest()} className="bg-emerald-600 text-xs hover:bg-emerald-700 sm:text-sm">
            <Share2 className="mr-1 h-4 w-4" /> Retake Test
          </Button>
        </div>
      </section>

      {/* Summary cards */}
      <section className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <SummaryCard icon={CheckCircle2} colorClass="text-emerald-600 bg-emerald-100" label="Correct" value={snapshot.correct} />
          <SummaryCard icon={XCircle} colorClass="text-rose-600 bg-rose-100" label="Incorrect" value={snapshot.incorrect} />
          <SummaryCard icon={Target} colorClass="text-amber-600 bg-amber-100" label="Unattempted" value={snapshot.unattempted} />
          <SummaryCard icon={TrendingUp} colorClass="text-sky-600 bg-sky-100" label="Attempted" value={snapshot.attempted} />
        </div>

        {/* Section-wise breakdown */}
        {sectionBreakdown.length > 1 && (
          <Card className="mt-6 border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Timer className="h-4 w-4 text-slate-500" /> Section-wise Performance
              </CardTitle>
              <CardDescription className="text-xs">
                Per-section breakdown of correct, incorrect, unattempted and net marks.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                      <th className="py-2 pr-4 text-left font-medium">Section</th>
                      <th className="py-2 px-3 text-right font-medium">Total</th>
                      <th className="py-2 px-3 text-right font-medium">Correct</th>
                      <th className="py-2 px-3 text-right font-medium">Wrong</th>
                      <th className="py-2 px-3 text-right font-medium">Skipped</th>
                      <th className="py-2 pl-3 text-right font-medium">Marks</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sectionBreakdown.map(([section, e]) => (
                      <tr key={section} className="border-b border-slate-100 last:border-0">
                        <td className="py-2 pr-4 text-sm font-medium text-slate-800">{section}</td>
                        <td className="py-2 px-3 text-right text-slate-600">{e.total}</td>
                        <td className="py-2 px-3 text-right text-emerald-600">{e.correct}</td>
                        <td className="py-2 px-3 text-right text-rose-600">{e.incorrect}</td>
                        <td className="py-2 px-3 text-right text-slate-500">{e.unattempted}</td>
                        <td className="py-2 pl-3 text-right font-semibold text-slate-900">
                          {Math.round(e.marks * 100) / 100}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Question-by-question review */}
        <Card className="mt-6 border-slate-200">
          <CardHeader>
            <CardTitle className="text-base">Question-wise Solutions</CardTitle>
            <CardDescription className="text-xs">
              Review each question with your answer, the correct answer and the explanation.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" onValueChange={(v) => setFilter(v as typeof filter)} className="w-full">
              <TabsList className="mb-4 grid w-full grid-cols-2 sm:grid-cols-4">
                <TabsTrigger value="all" className="text-xs">All ({questionAnalysis.length})</TabsTrigger>
                <TabsTrigger value="correct" className="text-xs">
                  <CheckCircle2 className="mr-1 h-3.5 w-3.5 text-emerald-600" /> Correct ({snapshot.correct})
                </TabsTrigger>
                <TabsTrigger value="incorrect" className="text-xs">
                  <XCircle className="mr-1 h-3.5 w-3.5 text-rose-600" /> Wrong ({snapshot.incorrect})
                </TabsTrigger>
                <TabsTrigger value="unattempted" className="text-xs">Skipped ({snapshot.unattempted})</TabsTrigger>
              </TabsList>
              <TabsContent value={filter} className="mt-0">
                <div className="space-y-3">
                  {filtered.map((q) => (
                    <SolutionCard
                      key={q.id}
                      index={q.idx}
                      question={q.question}
                      options={q.options}
                      correctOptions={q.correctOptions}
                      userSelection={q.userSel}
                      isAttempted={q.isAttempted}
                      isCorrect={q.isCorrect}
                      explanation={q.explanation}
                      section={q.section}
                      negativeMarking={activeMockTest.negativeMarking}
                      perQuestionMark={perQuestionMark}
                    />
                  ))}
                  {filtered.length === 0 && (
                    <div className="rounded-md border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">
                      No questions in this filter.
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}

function BigStat({ label, value, subValue }: { label: string; value: string; subValue?: string }) {
  return (
    <div className="rounded-lg border border-white/20 bg-white/10 px-3 py-3 text-center backdrop-blur-sm">
      <div className="text-[10px] uppercase tracking-wider text-white/80">{label}</div>
      <div className="mt-1 text-xl font-bold sm:text-2xl">{value}</div>
      {subValue && <div className="text-[10px] text-white/70">{subValue}</div>}
    </div>
  );
}

function SummaryCard({ icon: Icon, colorClass, label, value }: { icon: React.ElementType; colorClass: string; label: string; value: number }) {
  return (
    <Card className="border-slate-200">
      <CardContent className="flex items-center gap-3 p-4">
        <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${colorClass}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="text-2xl font-bold text-slate-900">{value}</div>
          <div className="text-xs text-slate-500">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function SolutionCard({
  index,
  question,
  options,
  correctOptions,
  userSelection,
  isAttempted,
  isCorrect,
  explanation,
  section,
  negativeMarking,
  perQuestionMark,
}: {
  index: number;
  question: string;
  options: string[];
  correctOptions: number[];
  userSelection: number[];
  isAttempted: boolean;
  isCorrect: boolean;
  explanation: string;
  section: string;
  negativeMarking: number;
  perQuestionMark: number;
}) {
  const userSet = new Set(userSelection);
  const correctSet = new Set(correctOptions);
  const marks = isCorrect ? perQuestionMark : isAttempted ? -negativeMarking : 0;

  return (
    <div className={`rounded-lg border bg-white p-4 transition-all ${isCorrect ? "border-emerald-200" : isAttempted ? "border-rose-200" : "border-slate-200"}`}>
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Q{index + 1}</span>
          <Badge variant="outline" className="text-[10px]">{section}</Badge>
        </div>
        <div className="flex items-center gap-2">
          <span className={`rounded-md px-2 py-0.5 text-[11px] font-semibold ${
            isCorrect ? "bg-emerald-100 text-emerald-700" : isAttempted ? "bg-rose-100 text-rose-700" : "bg-slate-100 text-slate-600"
          }`}>
            {isCorrect ? "Correct" : isAttempted ? "Incorrect" : "Skipped"}
          </span>
          <span className={`text-xs font-semibold ${marks > 0 ? "text-emerald-600" : marks < 0 ? "text-rose-600" : "text-slate-500"}`}>
            {marks > 0 ? `+${marks.toFixed(2)}` : marks < 0 ? `${marks.toFixed(2)}` : "0.00"}
          </span>
        </div>
      </div>
      <p className="text-sm leading-6 text-slate-800">{question}</p>
      <div className="mt-3 space-y-1.5">
        {options.map((opt, oi) => {
          const isUserChoice = userSet.has(oi);
          const isCorrectChoice = correctSet.has(oi);
          return (
            <div
              key={oi}
              className={`flex items-start gap-2 rounded-md border px-2 py-1.5 text-xs ${
                isCorrectChoice
                  ? "border-emerald-200 bg-emerald-50"
                  : isUserChoice
                    ? "border-rose-200 bg-rose-50"
                    : "border-slate-200 bg-white"
              }`}
            >
              <span className="font-semibold text-slate-600">{String.fromCharCode(65 + oi)}.</span>
              <span className="flex-1 text-slate-700">{opt}</span>
              {isCorrectChoice && <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-600" />}
              {isUserChoice && !isCorrectChoice && <XCircle className="h-3.5 w-3.5 shrink-0 text-rose-600" />}
              {isUserChoice && isCorrectChoice && (
                <span className="text-[10px] font-semibold text-emerald-700">Your choice</span>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-3 rounded-md bg-amber-50 px-3 py-2">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-amber-700">Explanation</div>
        <p className="mt-0.5 text-xs leading-5 text-amber-900">{explanation}</p>
      </div>
    </div>
  );
}
