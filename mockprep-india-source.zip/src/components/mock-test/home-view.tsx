"use client";

import { categories } from "@/lib/categories";
import { allExams } from "@/lib/exams";
import { useTestStore } from "@/lib/test-store";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import * as Icons from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

export function HomeView() {
  const navigate = useTestStore((s) => s.navigate);

  const totalExams = allExams.length;
  const totalMocks = allExams.reduce((sum, e) => sum + e.mockTests.length, 0);
  const totalQuestions = allExams.reduce(
    (sum, e) => sum + e.mockTests.reduce((s, m) => s + m.questions.length, 0),
    0,
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-gradient-to-br from-emerald-700 via-teal-700 to-cyan-800 text-white">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)", backgroundSize: "32px 32px" }} />
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge className="mb-4 bg-white/15 text-white border-white/20 hover:bg-white/20">
              India&apos;s Largest CBT Mock Test Platform
            </Badge>
            <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
              Crack Every Government Exam in India
            </h1>
            <p className="mt-6 text-lg leading-8 text-emerald-50/90 sm:text-xl">
              Practice real-time Computer Based Test (CBT) mocks for SSC, UPSC, Banking,
              Railway, Defence, Teaching, Police, Insurance, State PSC &amp; Postal exams —
              with authentic patterns, prescribed timers and detailed solutions.
            </p>
            <div className="mt-8 grid grid-cols-3 gap-3 sm:gap-6">
              <StatCard value={`${totalExams}+`} label="Live Exams" />
              <StatCard value={`${totalMocks}+`} label="Mock Tests" />
              <StatCard value={`${totalQuestions}+`} label="Practice Questions" />
            </div>
          </motion.div>
        </div>
        <svg className="absolute bottom-0 w-full" viewBox="0 0 1440 60" preserveAspectRatio="none" style={{ height: 40 }}>
          <path d="M0,40 C360,80 1080,0 1440,40 L1440,60 L0,60 Z" fill="white" />
        </svg>
      </section>

      {/* Categories grid */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
              Browse Exam Categories
            </h2>
            <p className="mt-2 text-slate-600">
              Pick a category to explore its exams, syllabus and mock tests.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {categories.map((cat, idx) => {
            const examCount = allExams.filter((e) => e.categoryId === cat.id).length;
            const mockCount = allExams
              .filter((e) => e.categoryId === cat.id)
              .reduce((sum, e) => sum + e.mockTests.length, 0);
            const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[cat.icon] ?? Icons.FileText;
            return (
              <motion.button
                key={cat.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: idx * 0.04 }}
                onClick={() => navigate("category", { categoryId: cat.id })}
                className="group text-left"
              >
                <Card className="relative h-full overflow-hidden border-slate-200 transition-all hover:-translate-y-1 hover:shadow-xl">
                  <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${cat.color}`} />
                  <CardHeader className="pt-5">
                    <div className={`mb-3 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${cat.color} text-white shadow-lg`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="text-lg">{cat.name}</CardTitle>
                    <CardDescription className="text-xs">
                      {examCount} {examCount === 1 ? "exam" : "exams"} · {mockCount} mock{mockCount === 1 ? "" : "s"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-5 text-slate-600 line-clamp-3">
                      {cat.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Featured exams strip */}
      <section className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
            Popular Mock Tests
          </h2>
          <p className="mt-2 text-slate-600">
            Jump straight into the most attempted CBT mocks.
          </p>
          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {allExams.slice(0, 6).map((exam) => {
              const mt = exam.mockTests[0];
              if (!mt) return null;
              return (
                <button
                  key={`${exam.id}-${mt.id}`}
                  onClick={() => navigate("exam", { examId: exam.id })}
                  className="group text-left"
                >
                  <Card className="h-full border-slate-200 transition-all hover:border-emerald-300 hover:shadow-md">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between gap-2">
                        <Badge variant="outline" className="text-[10px] uppercase tracking-wide">
                          {exam.categoryId}
                        </Badge>
                        <span className="text-xs text-slate-500">{exam.conductingBody}</span>
                      </div>
                      <CardTitle className="mt-2 text-base">{mt.name}</CardTitle>
                      <CardDescription className="line-clamp-2 text-xs">
                        {mt.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex flex-wrap gap-2 text-[11px] text-slate-600">
                        <span className="rounded-md bg-slate-100 px-2 py-0.5">{mt.totalQuestions} Questions</span>
                        <span className="rounded-md bg-slate-100 px-2 py-0.5">{mt.durationMinutes} min</span>
                        <span className="rounded-md bg-slate-100 px-2 py-0.5">{mt.totalMarks} marks</span>
                      </div>
                    </CardContent>
                  </Card>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="border-t border-slate-200 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl text-center">
            How MockPrep India Works
          </h2>
          <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-3">
            {[
              { icon: "Layers", title: "Choose an Exam", desc: "Pick from 17+ Indian government exams — SSC, UPSC, IBPS, RRB, CDS, NDA, CTET and more. Browse the original syllabus & pattern before you start." },
              { icon: "Timer", title: "Attempt the CBT Mock", desc: "Take the test in a real exam-like interface with question palette, mark-for-review, sectional / single timer, save & next — exactly like the original CBT." },
              { icon: "ChartNoAxesColumn", title: "Get Detailed Analysis", desc: "Instantly view your score, accuracy, time spent per question and detailed explanations for every question — auto-submit when the timer hits zero." },
            ].map((step, idx) => {
              const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[step.icon];
              return (
                <div key={idx} className="rounded-xl border border-slate-200 bg-white p-6 text-center">
                  <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="text-base font-semibold text-slate-900">{step.title}</h3>
                  <p className="mt-2 text-sm text-slate-600">{step.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

function StatCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-lg border border-white/20 bg-white/10 px-3 py-2 backdrop-blur-sm sm:px-4 sm:py-3">
      <div className="text-xl font-bold sm:text-2xl">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-emerald-100/80 sm:text-xs">
        {label}
      </div>
    </div>
  );
}
