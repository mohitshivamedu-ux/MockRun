"use client";

import { categories } from "@/lib/categories";
import { getExamsByCategory } from "@/lib/exams";
import { useTestStore } from "@/lib/test-store";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import * as Icons from "lucide-react";
import { ArrowLeft, Clock, FileText, ListChecks } from "lucide-react";

export function CategoryView() {
  const categoryId = useTestStore((s) => s.activeCategoryId);
  const navigate = useTestStore((s) => s.navigate);

  if (!categoryId) return null;
  const category = categories.find((c) => c.id === categoryId);
  const exams = getExamsByCategory(categoryId);

  if (!category) return null;

  const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[category.icon] ?? Icons.FileText;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Banner */}
      <section className={`bg-gradient-to-br ${category.color} text-white`}>
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 lg:py-12">
          <Button
            variant="ghost"
            onClick={() => navigate("home")}
            className="mb-4 -ml-2 text-white/90 hover:bg-white/10 hover:text-white"
          >
            <ArrowLeft className="mr-1 h-4 w-4" /> Back to Home
          </Button>
          <div className="flex items-start gap-4">
            <div className="inline-flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-sm">
              <Icon className="h-7 w-7" />
            </div>
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
                {category.name} Exams
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-white/90 sm:text-base">
                {category.description}
              </p>
              <div className="mt-3 flex flex-wrap gap-2 text-xs">
                <span className="rounded-full bg-white/15 px-3 py-1 backdrop-blur-sm">
                  {exams.length} exam{exams.length === 1 ? "" : "s"}
                </span>
                <span className="rounded-full bg-white/15 px-3 py-1 backdrop-blur-sm">
                  {exams.reduce((s, e) => s + e.mockTests.length, 0)} mock test{exams.reduce((s, e) => s + e.mockTests.length, 0) === 1 ? "" : "s"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        {exams.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center">
            <p className="text-slate-600">No exams available in this category yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            {exams.map((exam) => {
              const totalQ = exam.mockTests.reduce((s, m) => s + m.totalQuestions, 0);
              return (
                <Card key={exam.id} className="border-slate-200 transition-all hover:shadow-md">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <CardTitle className="text-xl">{exam.name}</CardTitle>
                        <CardDescription className="mt-1 text-xs">
                          {exam.fullName}
                        </CardDescription>
                      </div>
                      <Badge style={{ backgroundColor: category.accent }} className="shrink-0 text-white">
                        {exam.conductingBody.split("(")[0].trim()}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-6 text-slate-600 line-clamp-3">
                      {exam.description}
                    </p>
                    <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
                      <div className="rounded-md bg-slate-50 px-2 py-1.5 text-center">
                        <ListChecks className="mx-auto mb-0.5 h-3.5 w-3.5 text-slate-500" />
                        <div className="font-semibold text-slate-900">{exam.mockTests.length}</div>
                        <div className="text-slate-500">Mocks</div>
                      </div>
                      <div className="rounded-md bg-slate-50 px-2 py-1.5 text-center">
                        <FileText className="mx-auto mb-0.5 h-3.5 w-3.5 text-slate-500" />
                        <div className="font-semibold text-slate-900">{totalQ}</div>
                        <div className="text-slate-500">Questions</div>
                      </div>
                      <div className="rounded-md bg-slate-50 px-2 py-1.5 text-center">
                        <Clock className="mx-auto mb-0.5 h-3.5 w-3.5 text-slate-500" />
                        <div className="font-semibold text-slate-900">{exam.examPattern[0]?.durationMinutes ?? 0}</div>
                        <div className="text-slate-500">Minutes</div>
                      </div>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {exam.syllabus.slice(0, 4).map((s) => (
                        <span
                          key={s.name}
                          className="rounded-md border border-slate-200 bg-white px-2 py-0.5 text-[10px] text-slate-600"
                        >
                          {s.name}
                        </span>
                      ))}
                      {exam.syllabus.length > 4 && (
                        <span className="rounded-md border border-slate-200 bg-white px-2 py-0.5 text-[10px] text-slate-500">
                          +{exam.syllabus.length - 4} more
                        </span>
                      )}
                    </div>
                    <Button
                      onClick={() => navigate("exam", { examId: exam.id })}
                      className="mt-5 w-full"
                      style={{ backgroundColor: category.accent }}
                    >
                      View Exam Details
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
