"use client";

import { categories } from "@/lib/categories";
import { getExamById } from "@/lib/exams";
import { useTestStore } from "@/lib/test-store";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, BookOpen, Building2, CalendarDays, CheckCircle2, GraduationCap, Play, ScrollText, Users } from "lucide-react";

export function ExamDetailView() {
  const examId = useTestStore((s) => s.activeExamId);
  const navigate = useTestStore((s) => s.navigate);

  if (!examId) return null;
  const exam = getExamById(examId);
  if (!exam) return null;
  const category = categories.find((c) => c.id === exam.categoryId);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Banner */}
      <section className={`bg-gradient-to-br ${category?.color ?? "from-slate-700 to-slate-800"} text-white`}>
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
          <Button
            variant="ghost"
            onClick={() => navigate("category", { categoryId: exam.categoryId })}
            className="mb-4 -ml-2 text-white/90 hover:bg-white/10 hover:text-white"
          >
            <ArrowLeft className="mr-1 h-4 w-4" /> Back to {category?.name} Exams
          </Button>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-3xl">
              <div className="mb-2 flex flex-wrap gap-2">
                <Badge className="bg-white/15 text-white border-white/20">{category?.name}</Badge>
                <Badge className="bg-white/15 text-white border-white/20">{exam.conductingBody}</Badge>
              </div>
              <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{exam.name}</h1>
              <p className="mt-1 text-sm text-white/85 sm:text-base">{exam.fullName}</p>
              <p className="mt-4 text-sm leading-6 text-white/90">{exam.description}</p>
              <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
                <InfoChip icon={CalendarDays} label="Frequency" value={exam.frequency} />
                <InfoChip icon={GraduationCap} label="Eligibility" value={exam.eligibility} />
                <InfoChip icon={Users} label="Age Limit" value={exam.ageLimit} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {/* Left: Mock tests + syllabus */}
          <div className="space-y-8 lg:col-span-2">
            {/* Mock tests */}
            <div>
              <SectionHeader icon={Play} title="Available Mock Tests" subtitle="Take a full CBT-format mock — same pattern, timer and marking scheme as the original exam." />
              <div className="space-y-4">
                {exam.mockTests.map((mt) => (
                  <Card key={mt.id} className="border-slate-200">
                    <CardHeader>
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <CardTitle className="text-lg">{mt.name}</CardTitle>
                          <CardDescription className="mt-1">{mt.description}</CardDescription>
                        </div>
                        <Badge variant="outline" className="shrink-0">{mt.difficulty}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
                        <Metric label="Questions" value={`${mt.totalQuestions}`} />
                        <Metric label="Total Marks" value={`${mt.totalMarks}`} />
                        <Metric label="Duration" value={`${mt.durationMinutes} min`} />
                        <Metric label="Negative Marking" value={mt.negativeMarking > 0 ? `−${mt.negativeMarking}` : "None"} />
                      </div>
                      <Button
                        onClick={() => navigate("test-instructions", { mockTestId: mt.id })}
                        className="mt-5 w-full"
                        style={{ backgroundColor: category?.accent }}
                      >
                        <Play className="mr-1 h-4 w-4" /> Start Mock Test
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Syllabus */}
            <div>
              <SectionHeader icon={BookOpen} title="Syllabus" subtitle="Original syllabus prescribed by the conducting body. Topics are listed section-wise." />
              <Card className="border-slate-200">
                <CardContent className="pt-6">
                  <Accordion type="multiple" defaultValue={exam.syllabus.slice(0, 1).map((_, i) => `syllabus-${i}`)} className="w-full">
                    {exam.syllabus.map((section, idx) => (
                      <AccordionItem key={section.name} value={`syllabus-${idx}`}>
                        <AccordionTrigger className="text-sm font-semibold text-slate-900 hover:no-underline">
                          {section.name}
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="flex flex-wrap gap-2 pb-2">
                            {section.topics.map((topic) => (
                              <span
                                key={topic}
                                className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700"
                              >
                                <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                                {topic}
                              </span>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Right: Exam pattern + conducting body */}
          <div className="space-y-8">
            <div>
              <SectionHeader icon={ScrollText} title="Exam Pattern" subtitle="Tier-wise structure of the actual exam." />
              <div className="space-y-4">
                {exam.examPattern.map((tier) => (
                  <Card key={tier.tier} className="border-slate-200">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">{tier.tier}</CardTitle>
                      <CardDescription className="text-xs">{tier.name} · {tier.mode}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <Table>
                        <TableHeader>
                          <TableRow className="text-xs">
                            <TableHead className="h-8 py-1">Section</TableHead>
                            <TableHead className="h-8 py-1 text-right">Qs</TableHead>
                            <TableHead className="h-8 py-1 text-right">Marks</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {tier.sections.map((sec) => (
                            <TableRow key={sec.name} className="text-xs">
                              <TableCell className="py-1.5">{sec.name}</TableCell>
                              <TableCell className="py-1.5 text-right">{sec.questions}</TableCell>
                              <TableCell className="py-1.5 text-right">{sec.marks}</TableCell>
                            </TableRow>
                          ))}
                          <TableRow className="font-semibold">
                            <TableCell className="py-1.5">Total</TableCell>
                            <TableCell className="py-1.5 text-right">{tier.totalQuestions}</TableCell>
                            <TableCell className="py-1.5 text-right">{tier.totalMarks}</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                      <div className="mt-3 grid grid-cols-3 gap-2 text-[11px]">
                        <Metric label="Duration" value={`${tier.durationMinutes} min`} />
                        <Metric label="Negative" value={tier.negativeMarking > 0 ? `−${tier.negativeMarking}` : "None"} />
                        <Metric label="Type" value={tier.qualifying ? "Qualifying" : "Merit"} />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Building2 className="h-4 w-4 text-slate-500" /> Conducting Body
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-700">{exam.conductingBody}</p>
                <p className="mt-2 text-xs text-slate-500">Frequency: {exam.frequency}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}

function SectionHeader({ icon: Icon, title, subtitle }: { icon: React.ElementType; title: string; subtitle: string }) {
  return (
    <div className="mb-4 flex items-start gap-3">
      <div className="mt-0.5 flex h-9 w-9 items-center justify-center rounded-lg bg-slate-900 text-white">
        <Icon className="h-4 w-4" />
      </div>
      <div>
        <h2 className="text-lg font-bold tracking-tight text-slate-900">{title}</h2>
        <p className="text-xs text-slate-500">{subtitle}</p>
      </div>
    </div>
  );
}

function InfoChip({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/20 bg-white/10 p-3 backdrop-blur-sm">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-white/80">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className="mt-1 text-xs leading-4 text-white">{value}</div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-slate-50 px-2 py-1.5 text-center">
      <div className="font-semibold text-slate-900">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
    </div>
  );
}
