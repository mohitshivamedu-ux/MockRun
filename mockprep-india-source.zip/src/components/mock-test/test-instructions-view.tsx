"use client";

import { getExamById, getMockTestById } from "@/lib/exams";
import { useTestStore } from "@/lib/test-store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, ArrowLeft, CheckCircle2, Clock, FileText, ListChecks, Play, XCircle } from "lucide-react";

export function TestInstructionsView() {
  const examId = useTestStore((s) => s.activeExamId);
  const mockTestId = useTestStore((s) => s.activeMockTestId);
  const navigate = useTestStore((s) => s.navigate);
  const startTest = useTestStore((s) => s.startTest);

  if (!examId || !mockTestId) return null;
  const exam = getExamById(examId);
  const test = getMockTestById(examId, mockTestId);
  if (!exam || !test) return null;

  // Build a section breakdown for this mock
  const sectionMap = new Map<string, number>();
  test.questions.forEach((q) => {
    sectionMap.set(q.section, (sectionMap.get(q.section) ?? 0) + 1);
  });
  const sections = Array.from(sectionMap.entries());

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-slate-900 text-white">
        <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-8">
          <Button
            variant="ghost"
            onClick={() => navigate("exam", { examId })}
            className="mb-2 -ml-2 text-white/80 hover:bg-white/10 hover:text-white"
          >
            <ArrowLeft className="mr-1 h-4 w-4" /> Back to Exam Details
          </Button>
          <h1 className="text-2xl font-bold sm:text-3xl">{test.name}</h1>
          <p className="mt-1 text-sm text-white/80">{exam.fullName}</p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <StatCard icon={ListChecks} label="Questions" value={`${test.totalQuestions}`} />
          <StatCard icon={FileText} label="Total Marks" value={`${test.totalMarks}`} />
          <StatCard icon={Clock} label="Duration" value={`${test.durationMinutes} min`} />
          <StatCard icon={AlertCircle} label="Negative" value={test.negativeMarking > 0 ? `−${test.negativeMarking}` : "None"} />
        </div>

        <Card className="mt-6 border-slate-200">
          <CardHeader>
            <CardTitle className="text-base">Test Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm leading-6 text-slate-700">{test.description}</p>
            <div className="mt-4">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">Sections</h3>
              <div className="mt-2 flex flex-wrap gap-2">
                {sections.map(([sec, count]) => (
                  <span
                    key={sec}
                    className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1 text-xs text-slate-700"
                  >
                    <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                    {sec} <span className="text-slate-400">· {count} Qs</span>
                  </span>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-6 border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base text-amber-900">
              <AlertCircle className="h-5 w-5" /> General Instructions
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm leading-6 text-amber-900">
            <ul className="list-disc space-y-1.5 pl-5">
              <li>The test will start as soon as you click the &quot;Start Test&quot; button below.</li>
              <li>A live timer of <strong>{test.durationMinutes} minutes</strong> will begin counting down. The test will be auto-submitted when the timer hits zero.</li>
              <li>Use the <strong>question palette</strong> on the right to jump to any question. Colours indicate status (see legend below).</li>
              <li>Use <strong>Save &amp; Next</strong> to save your response and move to the next question.</li>
              <li>Use <strong>Mark for Review &amp; Next</strong> to flag a question for later review (your answer, if any, will be considered in evaluation if you don&apos;t change it).</li>
              <li>Use <strong>Clear Response</strong> to deselect your chosen option for the current question.</li>
              <li>For each correct answer you get <strong>+{(test.totalMarks / test.totalQuestions).toFixed(2)} marks</strong>; for each wrong answer, <strong>−{test.negativeMarking} marks</strong> are deducted (if negative marking is applicable).</li>
              <li>You can submit the test anytime using the <strong>Submit Test</strong> button — you will be asked to confirm.</li>
            </ul>
          </CardContent>
        </Card>

        {/* Palette legend */}
        <Card className="mt-6 border-slate-200">
          <CardHeader>
            <CardTitle className="text-base">Question Palette Legend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <LegendItem bgClass="bg-white border border-slate-300 text-slate-700" label="Not Visited" />
              <LegendItem bgClass="bg-rose-500 text-white" label="Not Answered" />
              <LegendItem bgClass="bg-emerald-500 text-white" label="Answered" />
              <LegendItem bgClass="bg-violet-500 text-white" label="Marked for Review" />
              <LegendItem bgClass="bg-violet-500 text-white ring-2 ring-emerald-400" label="Answered & Marked" />
              <LegendItem bgClass="bg-sky-500 text-white" label="Current Question" />
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 flex items-center justify-between gap-4">
          <Button variant="outline" onClick={() => navigate("exam", { examId })}>
            <ArrowLeft className="mr-1 h-4 w-4" /> Cancel
          </Button>
          <Button size="lg" onClick={() => startTest(test)} className="bg-emerald-600 hover:bg-emerald-700">
            <Play className="mr-1 h-4 w-4" /> Start Test Now
          </Button>
        </div>

        <p className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-500">
          <XCircle className="h-3.5 w-3.5" />
          Once started, the timer cannot be paused. Ensure you have a stable internet connection.
        </p>
      </section>
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 text-center">
      <Icon className="mx-auto mb-1 h-5 w-5 text-slate-500" />
      <div className="text-xl font-bold text-slate-900">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
    </div>
  );
}

function LegendItem({ bgClass, label }: { bgClass: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`inline-flex h-7 w-7 items-center justify-center rounded-md text-[11px] font-medium ${bgClass}`}>
        ✓
      </span>
      <span className="text-xs text-slate-700">{label}</span>
    </div>
  );
}
