"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { getExamById } from "@/lib/exams";
import {
  formatTime,
  paletteColorClass,
  useTestStore,
  type PaletteState,
} from "@/lib/test-store";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import {
  ChevronLeft,
  ChevronRight,
  CircleDot,
  Clock,
  Eye,
  Flag,
  ListChecks,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from "lucide-react";

export function TestRunningView() {
  const activeMockTest = useTestStore((s) => s.activeMockTest);
  const activeExamId = useTestStore((s) => s.activeExamId);
  const currentIndex = useTestStore((s) => s.currentIndex);
  const questionStates = useTestStore((s) => s.questionStates);
  const timeRemainingMs = useTestStore((s) => s.timeRemainingMs);
  const isTimerRunning = useTestStore((s) => s.isTimerRunning);
  const tick = useTestStore((s) => s.tick);
  const selectOption = useTestStore((s) => s.selectOption);
  const clearResponse = useTestStore((s) => s.clearResponse);
  const saveAndNext = useTestStore((s) => s.saveAndNext);
  const markForReviewAndNext = useTestStore((s) => s.markForReviewAndNext);
  const next = useTestStore((s) => s.next);
  const prev = useTestStore((s) => s.prev);
  const goToQuestion = useTestStore((s) => s.goToQuestion);
  const submitTest = useTestStore((s) => s.submitTest);

  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [mobilePaletteOpen, setMobilePaletteOpen] = useState(false);
  const exam = activeExamId ? getExamById(activeExamId) : null;
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Timer effect
  useEffect(() => {
    if (!isTimerRunning) return;
    intervalRef.current = setInterval(() => {
      tick(Date.now());
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isTimerRunning, tick]);

  const counts = useMemo(() => {
    const c = { answered: 0, notAnswered: 0, notVisited: 0, marked: 0, answeredMarked: 0 };
    if (!activeMockTest) return c;
    activeMockTest.questions.forEach((q) => {
      const st = questionStates[q.id];
      if (!st) return;
      // Treat 'current' as the visual highlight only — for counts, use underlying
      if (st.status === "answered") c.answered += 1;
      else if (st.status === "not-answered") c.notAnswered += 1;
      else if (st.status === "marked-for-review") c.marked += 1;
      else if (st.status === "answered-and-marked") c.answeredMarked += 1;
      else if (st.status === "current") {
        if (st.selectedOptions.length > 0) c.answered += 1;
        else c.notAnswered += 1;
      } else if (st.status === "not-visited") c.notVisited += 1;
    });
    return c;
  }, [questionStates, activeMockTest]);

  // Section detection — must run BEFORE any early return to satisfy rules-of-hooks
  const sectionGroups = useMemo(() => {
    if (!activeMockTest) return [];
    const groups: { section: string; indices: number[] }[] = [];
    activeMockTest.questions.forEach((q, idx) => {
      const lastGroup = groups[groups.length - 1];
      if (lastGroup && lastGroup.section === q.section) {
        lastGroup.indices.push(idx);
      } else {
        groups.push({ section: q.section, indices: [idx] });
      }
    });
    return groups;
  }, [activeMockTest]);

  if (!activeMockTest) return null;

  const currentQ = activeMockTest.questions[currentIndex];
  if (!currentQ) return null;
  const currentSt = questionStates[currentQ.id];

  const totalQs = activeMockTest.questions.length;
  const attempted = counts.answered + counts.answeredMarked;
  const notAttempted = counts.notAnswered + counts.notVisited + counts.marked;

  return (
    <div className="flex h-screen flex-col bg-slate-100">
      {/* Top header */}
      <header className="flex items-center justify-between border-b border-slate-300 bg-white px-3 py-2 shadow-sm sm:px-4 sm:py-3">
        <div className="flex min-w-0 items-center gap-2 sm:gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-slate-900 text-xs font-bold text-white sm:h-9 sm:w-9">
            {exam?.name?.slice(0, 4) ?? "TEST"}
          </div>
          <div className="min-w-0">
            <div className="truncate text-xs font-semibold text-slate-900 sm:text-sm">{activeMockTest.name}</div>
            <div className="truncate text-[10px] text-slate-500 sm:text-xs">{exam?.conductingBody}</div>
          </div>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <div className={`flex items-center gap-1.5 rounded-md px-2 py-1 font-mono text-sm font-bold tabular-nums sm:text-base ${timeRemainingMs < 60_000 ? "bg-rose-100 text-rose-700 animate-pulse" : timeRemainingMs < 5 * 60_000 ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}`}>
            <Clock className="h-4 w-4" />
            <span>{formatTime(timeRemainingMs)}</span>
          </div>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => setShowSubmitDialog(true)}
            className="hidden sm:inline-flex"
          >
            Submit Test
          </Button>
          <Button
            variant="destructive"
            size="icon"
            onClick={() => setShowSubmitDialog(true)}
            className="sm:hidden"
            aria-label="Submit Test"
          >
            <CheckCircle2 className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Main content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Question panel */}
        <main className="flex-1 overflow-y-auto bg-white">
          <div className="mx-auto max-w-4xl px-3 py-4 sm:px-6 sm:py-6">
            {/* Section + Question header */}
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-slate-900 text-white">{currentQ.section}</Badge>
                <span className="text-xs text-slate-500">
                  Question {currentIndex + 1} of {totalQs}
                </span>
              </div>
              <div className="text-xs text-slate-500">
                <span className="hidden sm:inline">Mark: +{(activeMockTest.totalMarks / activeMockTest.totalQuestions).toFixed(2)} · </span>
                <span className="text-rose-600">Neg: {activeMockTest.negativeMarking > 0 ? `−${activeMockTest.negativeMarking}` : "—"}</span>
              </div>
            </div>

            {/* Question text */}
            <div className="mb-5">
              <div className="rounded-md border-l-4 border-slate-300 bg-slate-50 px-3 py-2 text-xs text-slate-500">
                {currentQ.type === "single" ? "Choose the correct option" : "Choose all correct options"}
              </div>
              <p className="mt-3 text-base leading-7 text-slate-900 sm:text-lg">
                <span className="mr-2 font-semibold text-slate-500">Q{currentIndex + 1}.</span>
                {currentQ.question}
              </p>
            </div>

            {/* Options */}
            <div className="space-y-2.5">
              {currentQ.options.map((opt, oi) => {
                const isSelected = currentSt?.selectedOptions.includes(oi);
                return (
                  <button
                    key={oi}
                    onClick={() => selectOption(currentQ.id, oi)}
                    className={`group flex w-full items-start gap-3 rounded-lg border px-3 py-2.5 text-left text-sm transition-all sm:px-4 sm:py-3 ${
                      isSelected
                        ? "border-emerald-500 bg-emerald-50 ring-1 ring-emerald-200"
                        : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"
                    }`}
                  >
                    <span
                      className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-xs font-semibold transition-all ${
                        isSelected
                          ? "border-emerald-500 bg-emerald-500 text-white"
                          : "border-slate-300 bg-white text-slate-600 group-hover:border-slate-400"
                      }`}
                    >
                      {String.fromCharCode(65 + oi)}
                    </span>
                    <span className={`text-sm leading-6 sm:text-base ${isSelected ? "text-emerald-900" : "text-slate-700"}`}>
                      {opt}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Action row */}
            <div className="mt-6 flex flex-wrap items-center gap-2 border-t border-slate-200 pt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => clearResponse(currentQ.id)}
                disabled={currentSt?.selectedOptions.length === 0}
                className="text-xs sm:text-sm"
              >
                <CircleDot className="mr-1 h-3.5 w-3.5" /> Clear Response
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={markForReviewAndNext}
                className="border-violet-300 text-violet-700 hover:bg-violet-50 hover:text-violet-800 text-xs sm:text-sm"
              >
                <Flag className="mr-1 h-3.5 w-3.5" /> Mark &amp; Next
              </Button>
              <div className="flex-1" />
              <Button
                variant="outline"
                size="sm"
                onClick={prev}
                disabled={currentIndex === 0}
                className="text-xs sm:text-sm"
              >
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <Button
                size="sm"
                onClick={saveAndNext}
                disabled={currentIndex === totalQs - 1}
                className="bg-emerald-600 text-xs hover:bg-emerald-700 sm:text-sm"
              >
                Save &amp; Next <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </div>

            {/* Mobile palette toggle */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setMobilePaletteOpen(true)}
              className="mt-4 w-full border-slate-300 text-xs sm:hidden"
            >
              <ListChecks className="mr-1 h-3.5 w-3.5" /> View Question Palette
            </Button>
          </div>
        </main>

        {/* Desktop palette */}
        <aside className="hidden w-72 shrink-0 flex-col border-l border-slate-300 bg-white lg:flex">
          <PalettePanel
            counts={counts}
            totalQs={totalQs}
            attempted={attempted}
            notAttempted={notAttempted}
            sectionGroups={sectionGroups}
            currentIndex={currentIndex}
            questionStates={questionStates}
            onGoTo={goToQuestion}
          />
        </aside>
      </div>

      {/* Mobile palette drawer */}
      {mobilePaletteOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobilePaletteOpen(false)} />
          <div className="relative ml-auto flex h-full w-80 max-w-[85%] flex-col bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
              <h3 className="text-sm font-semibold">Question Palette</h3>
              <Button variant="ghost" size="sm" onClick={() => setMobilePaletteOpen(false)}>Close</Button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <PalettePanel
                counts={counts}
                totalQs={totalQs}
                attempted={attempted}
                notAttempted={notAttempted}
                sectionGroups={sectionGroups}
                currentIndex={currentIndex}
                questionStates={questionStates}
                onGoTo={(idx) => {
                  goToQuestion(idx);
                  setMobilePaletteOpen(false);
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Submit dialog */}
      <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" /> Submit Test?
            </AlertDialogTitle>
            <AlertDialogDescription>
              You have answered <strong>{attempted}</strong> of <strong>{totalQs}</strong> questions.
              {notAttempted > 0 && (
                <> You still have <strong>{notAttempted}</strong> not attempted.</>
              )}
              {timeRemainingMs > 0 && <> You still have <strong>{formatTime(timeRemainingMs)}</strong> remaining.</>}
              <br /><br />Are you sure you want to submit the test? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                setShowSubmitDialog(false);
                submitTest();
              }}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              Yes, Submit Test
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function PalettePanel({
  counts,
  totalQs,
  attempted,
  notAttempted,
  sectionGroups,
  currentIndex,
  questionStates,
  onGoTo,
}: {
  counts: { answered: number; notAnswered: number; notVisited: number; marked: number; answeredMarked: number };
  totalQs: number;
  attempted: number;
  notAttempted: number;
  sectionGroups: { section: string; indices: number[] }[];
  currentIndex: number;
  questionStates: Record<string, { selectedOptions: number[]; status: PaletteState; timeSpentMs: number }>;
  onGoTo: (index: number) => void;
}) {
  return (
    <div className="flex h-full flex-col">
      {/* Counts summary */}
      <div className="border-b border-slate-200 px-4 py-3">
        <div className="grid grid-cols-2 gap-1.5 text-[11px]">
          <CountChip colorClass="bg-emerald-500" label="Answered" value={counts.answered + counts.answeredMarked} />
          <CountChip colorClass="bg-rose-500" label="Not Answered" value={counts.notAnswered} />
          <CountChip colorClass="bg-white border border-slate-300 text-slate-700" label="Not Visited" value={counts.notVisited} />
          <CountChip colorClass="bg-violet-500" label="Marked" value={counts.marked + counts.answeredMarked} />
        </div>
        <div className="mt-2 flex justify-between rounded-md bg-slate-100 px-2 py-1 text-[11px] font-medium text-slate-700">
          <span>Attempted: {attempted}</span>
          <span>Left: {notAttempted}</span>
          <span>Total: {totalQs}</span>
        </div>
      </div>

      {/* Palette grid by section */}
      <div className="flex-1 overflow-y-auto px-3 py-3">
        {sectionGroups.map((group) => (
          <div key={group.section} className="mb-4">
            <div className="mb-2 flex items-center gap-1.5 px-1">
              <div className="h-1.5 w-1.5 rounded-full bg-slate-400" />
              <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                {group.section}
              </h4>
            </div>
            <div className="grid grid-cols-6 gap-1.5">
              {group.indices.map((idx) => {
                // Use index-based lookup since same-section questions may share ids with other sections
                // Actually question ids are unique — use them
                return <PaletteButton key={idx} index={idx} onClick={() => onGoTo(idx)} />;
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="border-t border-slate-200 bg-slate-50 px-4 py-3 text-[10px]">
        <div className="grid grid-cols-2 gap-1.5">
          <LegendChip colorClass="bg-white border border-slate-300" label="Not Visited" />
          <LegendChip colorClass="bg-rose-500" label="Not Answered" />
          <LegendChip colorClass="bg-emerald-500" label="Answered" />
          <LegendChip colorClass="bg-violet-500" label="Marked" />
        </div>
      </div>
    </div>
  );
}

function PaletteButton({ index, onClick }: { index: number; onClick: () => void }) {
  const activeMockTest = useTestStore((s) => s.activeMockTest);
  const currentIndex = useTestStore((s) => s.currentIndex);
  const questionStates = useTestStore((s) => s.questionStates);
  if (!activeMockTest) return null;
  const q = activeMockTest.questions[index];
  const st = questionStates[q.id];
  const status = st?.status ?? "not-visited";
  const visualStatus: PaletteState = index === currentIndex ? "current" : status === "current" ? (st && st.selectedOptions.length > 0 ? "answered" : "not-answered") : status;
  return (
    <button
      onClick={onClick}
      aria-label={`Go to question ${index + 1}`}
      className={`flex h-8 items-center justify-center rounded-md border text-xs font-semibold transition-all ${paletteColorClass(visualStatus)}`}
    >
      {index + 1}
    </button>
  );
}

function CountChip({ colorClass, label, value }: { colorClass: string; label: string; value: number }) {
  return (
    <div className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2 py-1">
      <span className={`inline-block h-3 w-3 rounded ${colorClass}`} />
      <span className="text-slate-600">{label}</span>
      <span className="ml-auto font-semibold text-slate-900">{value}</span>
    </div>
  );
}

function LegendChip({ colorClass, label }: { colorClass: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={`inline-block h-3 w-3 rounded ${colorClass}`} />
      <span className="text-slate-600">{label}</span>
    </div>
  );
}
