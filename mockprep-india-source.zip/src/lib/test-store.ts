import { create } from "zustand";
import type { MockTest, Question } from "./types";

export type PaletteState =
  | "not-visited" // grey
  | "not-answered" // red — visited but no option selected
  | "answered" // green — option saved
  | "marked-for-review" // purple
  | "answered-and-marked" // purple with green tick
  | "current"; // highlighted (current question)

export interface QuestionState {
  selectedOptions: number[]; // user's selected option indices
  status: PaletteState;
  timeSpentMs: number; // time spent on this question
}

export type ViewType =
  | "home"
  | "category"
  | "exam"
  | "test-instructions"
  | "test-running"
  | "result";

interface TestStore {
  // ---- navigation ----
  view: ViewType;
  activeCategoryId: string | null;
  activeExamId: string | null;
  activeMockTestId: string | null;

  // ---- test runtime state ----
  activeMockTest: MockTest | null;
  currentIndex: number;
  questionStates: Record<string, QuestionState>;
  timeRemainingMs: number;
  startedAt: number | null;
  endedAt: number | null;
  isTimerRunning: boolean;
  lastTickTs: number | null;

  // ---- result snapshot ----
  resultSnapshot: {
    totalQuestions: number;
    attempted: number;
    correct: number;
    incorrect: number;
    unattempted: number;
    marksObtained: number;
    totalMarks: number;
    accuracy: number;
    timeTakenMs: number;
  } | null;

  // ---- actions ----
  navigate: (view: ViewType, params?: { categoryId?: string; examId?: string; mockTestId?: string }) => void;
  startTest: (test: MockTest) => void;
  goToQuestion: (index: number) => void;
  selectOption: (questionId: string, optionIndex: number) => void;
  clearResponse: (questionId: string) => void;
  saveAndNext: () => void;
  markForReviewAndNext: () => void;
  next: () => void;
  prev: () => void;
  tick: (nowTs: number) => void;
  submitTest: () => void;
  resetTest: () => void;
}

const initialRuntime = {
  activeMockTest: null as MockTest | null,
  currentIndex: 0,
  questionStates: {} as Record<string, QuestionState>,
  timeRemainingMs: 0,
  startedAt: null as number | null,
  endedAt: null as number | null,
  isTimerRunning: false,
  lastTickTs: null as number | null,
  resultSnapshot: null,
};

export const useTestStore = create<TestStore>((set, get) => ({
  view: "home",
  activeCategoryId: null,
  activeExamId: null,
  activeMockTestId: null,
  ...initialRuntime,

  navigate: (view, params) =>
    set((s) => ({
      view,
      activeCategoryId: params?.categoryId ?? s.activeCategoryId,
      activeExamId: params?.examId ?? s.activeExamId,
      activeMockTestId: params?.mockTestId ?? s.activeMockTestId,
    })),

  startTest: (test) => {
    const states: Record<string, QuestionState> = {};
    test.questions.forEach((q, idx) => {
      states[q.id] = {
        selectedOptions: [],
        status: idx === 0 ? "current" : "not-visited",
        timeSpentMs: 0,
      };
    });
    set({
      activeMockTest: test,
      activeMockTestId: test.id,
      currentIndex: 0,
      questionStates: states,
      timeRemainingMs: test.durationMinutes * 60 * 1000,
      startedAt: Date.now(),
      endedAt: null,
      isTimerRunning: true,
      lastTickTs: Date.now(),
      resultSnapshot: null,
      view: "test-running",
    });
  },

  goToQuestion: (index) => {
    set((s) => {
      if (!s.activeMockTest) return s;
      const states = { ...s.questionStates };
      const currentQ = s.activeMockTest.questions[s.currentIndex];
      const targetQ = s.activeMockTest.questions[index];
      if (!targetQ) return s;
      // Update the leaving question
      if (currentQ && states[currentQ.id]) {
        const cur = states[currentQ.id];
        const leavingStatus: PaletteState =
          cur.status === "current"
            ? cur.selectedOptions.length > 0
              ? "answered"
              : "not-answered"
            : cur.status;
        states[currentQ.id] = { ...cur, status: leavingStatus };
      }
      // Mark incoming question — preserve its underlying state
      const incoming = states[targetQ.id];
      if (incoming) {
        states[targetQ.id] = {
          ...incoming,
          status:
            incoming.status === "answered" || incoming.status === "answered-and-marked"
              ? "answered"
              : "not-answered",
        };
        // Override current visual marker
        states[targetQ.id].status = "current";
      }
      return { questionStates: states, currentIndex: index };
    });
  },

  selectOption: (questionId, optionIndex) =>
    set((s) => {
      if (!s.activeMockTest) return s;
      const cur = s.questionStates[questionId];
      if (!cur) return s;
      // For single-choice: replace; for multiple: toggle
      const question = s.activeMockTest.questions.find((q) => q.id === questionId);
      let newSelection: number[];
      if (question?.type === "multiple") {
        newSelection = cur.selectedOptions.includes(optionIndex)
          ? cur.selectedOptions.filter((o) => o !== optionIndex)
          : [...cur.selectedOptions, optionIndex].sort((a, b) => a - b);
      } else {
        newSelection = [optionIndex];
      }
      return {
        questionStates: {
          ...s.questionStates,
          [questionId]: { ...cur, selectedOptions: newSelection },
        },
      };
    }),

  clearResponse: (questionId) =>
    set((s) => {
      const cur = s.questionStates[questionId];
      if (!cur) return s;
      return {
        questionStates: {
          ...s.questionStates,
          [questionId]: { ...cur, selectedOptions: [] },
        },
      };
    }),

  saveAndNext: () => {
    set((s) => {
      if (!s.activeMockTest) return s;
      const states = { ...s.questionStates };
      const curId = s.activeMockTest.questions[s.currentIndex].id;
      const cur = states[curId];
      const leavingStatus: PaletteState =
        cur.selectedOptions.length > 0 ? "answered" : "not-answered";
      states[curId] = { ...cur, status: leavingStatus };
      const nextIdx = s.currentIndex + 1;
      if (nextIdx < s.activeMockTest.questions.length) {
        const nextQ = s.activeMockTest.questions[nextIdx];
        const next = states[nextQ.id];
        if (next) {
          states[nextQ.id] = {
            ...next,
            status: next.status === "not-visited" ? "current" : "current",
          };
        }
        return { questionStates: states, currentIndex: nextIdx };
      }
      return { questionStates: states };
    });
  },

  markForReviewAndNext: () => {
    set((s) => {
      if (!s.activeMockTest) return s;
      const states = { ...s.questionStates };
      const curId = s.activeMockTest.questions[s.currentIndex].id;
      const cur = states[curId];
      const leavingStatus: PaletteState =
        cur.selectedOptions.length > 0 ? "answered-and-marked" : "marked-for-review";
      states[curId] = { ...cur, status: leavingStatus };
      const nextIdx = s.currentIndex + 1;
      if (nextIdx < s.activeMockTest.questions.length) {
        const nextQ = s.activeMockTest.questions[nextIdx];
        const next = states[nextQ.id];
        if (next) {
          states[nextQ.id] = { ...next, status: "current" };
        }
        return { questionStates: states, currentIndex: nextIdx };
      }
      return { questionStates: states };
    });
  },

  next: () =>
    set((s) => {
      if (!s.activeMockTest) return s;
      const nextIdx = Math.min(
        s.currentIndex + 1,
        s.activeMockTest.questions.length - 1,
      );
      get().goToQuestion(nextIdx);
      return {};
    }),

  prev: () =>
    set((s) => {
      if (!s.activeMockTest) return s;
      const prevIdx = Math.max(s.currentIndex - 1, 0);
      get().goToQuestion(prevIdx);
      return {};
    }),

  tick: (nowTs) => {
    set((s) => {
      if (!s.isTimerRunning || !s.activeMockTest) return s;
      const last = s.lastTickTs ?? nowTs;
      const delta = Math.max(0, nowTs - last);
      const remaining = Math.max(0, s.timeRemainingMs - delta);
      // Add time to current question
      const states = { ...s.questionStates };
      const curId = s.activeMockTest.questions[s.currentIndex].id;
      const cur = states[curId];
      if (cur) {
        states[curId] = {
          ...cur,
          timeSpentMs: cur.timeSpentMs + delta,
        };
      }
      if (remaining <= 0) {
        // Auto-submit
        const snapshot = computeResult(s, s.activeMockTest, true);
        return {
          timeRemainingMs: 0,
          isTimerRunning: false,
          lastTickTs: nowTs,
          endedAt: nowTs,
          questionStates: states,
          resultSnapshot: snapshot,
          view: "result",
        };
      }
      return {
        timeRemainingMs: remaining,
        lastTickTs: nowTs,
        questionStates: states,
      };
    });
  },

  submitTest: () => {
    set((s) => {
      if (!s.activeMockTest) return s;
      // Mark current question's leaving status before submit
      const states = { ...s.questionStates };
      const curId = s.activeMockTest.questions[s.currentIndex]?.id;
      if (curId && states[curId]) {
        const cur = states[curId];
        if (cur.status === "current") {
          states[curId] = {
            ...cur,
            status: cur.selectedOptions.length > 0 ? "answered" : "not-answered",
          };
        }
      }
      const snapshot = computeResult({ ...s, questionStates: states }, s.activeMockTest, false);
      return {
        questionStates: states,
        resultSnapshot: snapshot,
        isTimerRunning: false,
        endedAt: Date.now(),
        view: "result",
      };
    });
  },

  resetTest: () =>
    set({
      ...initialRuntime,
      view: "home",
      activeMockTest: null,
      activeMockTestId: null,
    }),
}));

function computeResult(
  state: TestStore,
  test: MockTest,
  autoSubmitted: boolean,
): TestStore["resultSnapshot"] {
  let correct = 0;
  let incorrect = 0;
  let unattempted = 0;
  let attempted = 0;
  const perQuestionMark = test.totalMarks / test.totalQuestions;
  let marksObtained = 0;
  test.questions.forEach((q: Question) => {
    const st = state.questionStates[q.id];
    if (!st || st.selectedOptions.length === 0) {
      unattempted += 1;
      return;
    }
    attempted += 1;
    const correctSet = new Set(q.correctOptions);
    const userSet = new Set(st.selectedOptions);
    const isCorrect =
      correctSet.size === userSet.size &&
      [...correctSet].every((o) => userSet.has(o));
    if (isCorrect) {
      correct += 1;
      marksObtained += perQuestionMark;
    } else {
      incorrect += 1;
      marksObtained -= test.negativeMarking;
    }
  });
  const totalMarks = test.totalMarks;
  const accuracy = attempted > 0 ? (correct / attempted) * 100 : 0;
  const timeTakenMs =
    state.startedAt != null
      ? (state.endedAt ?? Date.now()) - state.startedAt
      : 0;
  return {
    totalQuestions: test.questions.length,
    attempted,
    correct,
    incorrect,
    unattempted,
    marksObtained: Math.round(marksObtained * 100) / 100,
    totalMarks,
    accuracy: Math.round(accuracy * 100) / 100,
    timeTakenMs,
  };
}

export function formatTime(ms: number): string {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

export function paletteColorClass(status: PaletteState): string {
  switch (status) {
    case "answered":
      return "bg-emerald-500 text-white border-emerald-600";
    case "not-answered":
      return "bg-rose-500 text-white border-rose-600";
    case "marked-for-review":
      return "bg-violet-500 text-white border-violet-600";
    case "answered-and-marked":
      return "bg-violet-500 text-white border-violet-700 ring-2 ring-emerald-400";
    case "current":
      return "bg-sky-500 text-white border-sky-600 ring-2 ring-sky-300";
    case "not-visited":
    default:
      return "bg-white text-gray-700 border-gray-300 hover:border-gray-400";
  }
}
