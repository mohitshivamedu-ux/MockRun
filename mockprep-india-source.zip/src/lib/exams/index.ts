import type { Exam } from "../types";
import { sscExams } from "./ssc";
import { upscExams } from "./upsc";
import { bankingExams } from "./banking";
import { railwayExams } from "./railway";
import { otherExams } from "./other";

export const allExams: Exam[] = [
  ...sscExams,
  ...upscExams,
  ...bankingExams,
  ...railwayExams,
  ...otherExams,
];

export function getExamById(id: string): Exam | undefined {
  return allExams.find((e) => e.id === id);
}

export function getExamsByCategory(categoryId: string): Exam[] {
  return allExams.filter((e) => e.categoryId === categoryId);
}

export function getMockTestById(examId: string, mockTestId: string) {
  const exam = getExamById(examId);
  if (!exam) return undefined;
  return exam.mockTests.find((m) => m.id === mockTestId);
}
