export type QuestionType = "single" | "multiple";

export interface Question {
  id: string;
  section: string;
  topic?: string;
  type: QuestionType;
  question: string;
  options: string[];
  /** Index(es) of the correct option(s). For single-choice, length === 1. */
  correctOptions: number[];
  explanation: string;
}

export interface ExamPatternSection {
  name: string;
  questions: number;
  marks: number;
}

export interface ExamPattern {
  tier: string;
  name: string;
  mode: "Computer Based Test" | "OMR Based" | "Pen & Paper";
  sections: ExamPatternSection[];
  totalQuestions: number;
  totalMarks: number;
  durationMinutes: number;
  negativeMarking: number; // marks deducted per wrong answer
  qualifying: boolean;
}

export interface SyllabusSection {
  name: string;
  topics: string[];
}

export interface MockTest {
  id: string;
  examId: string;
  name: string;
  description: string;
  tier: string;
  durationMinutes: number;
  totalQuestions: number;
  totalMarks: number;
  negativeMarking: number;
  difficulty: "Easy" | "Moderate" | "Hard" | "Mixed";
  questions: Question[];
}

export interface Exam {
  id: string;
  name: string;
  fullName: string;
  categoryId: string;
  conductingBody: string;
  frequency: string;
  description: string;
  eligibility: string;
  ageLimit: string;
  syllabus: SyllabusSection[];
  examPattern: ExamPattern[];
  mockTests: MockTest[];
}

export interface ExamCategory {
  id: string;
  name: string;
  description: string;
  icon: string; // lucide icon name
  color: string; // tailwind gradient classes
  accent: string; // solid color hex for badges
}
