import type { ExamCategory } from "../types";

export const categories: ExamCategory[] = [
  {
    id: "ssc",
    name: "SSC",
    description:
      "Staff Selection Commission recruitment for various Group B & C posts across Central Government ministries.",
    icon: "Briefcase",
    color: "from-rose-500 to-orange-500",
    accent: "#e11d48",
  },
  {
    id: "upsc",
    name: "UPSC",
    description:
      "Union Public Service Commission — Civil Services, CDS, NDA, CAPF, ESE and other premier Group A exams.",
    icon: "Landmark",
    color: "from-emerald-600 to-teal-600",
    accent: "#047857",
  },
  {
    id: "banking",
    name: "Banking",
    description:
      "IBPS PO, Clerk, RRB, SBI PO/Clerk, RBI Grade B/Assistant — public sector bank recruitment exams.",
    icon: "Banknote",
    color: "from-amber-500 to-yellow-600",
    accent: "#b45309",
  },
  {
    id: "railway",
    name: "Railway",
    description:
      "RRB NTPC, Group D, ALP, JE — Indian Railways recruitment tests for graduate, undergraduate & technical posts.",
    icon: "TrainFront",
    color: "from-sky-600 to-cyan-600",
    accent: "#0369a1",
  },
  {
    id: "defence",
    name: "Defence",
    description:
      "CDS, NDA, AFCAT, Territorial Army — commission into Indian Army, Navy, Air Force via UPSC & service HQs.",
    icon: "Shield",
    color: "from-stone-600 to-zinc-700",
    accent: "#44403c",
  },
  {
    id: "teaching",
    name: "Teaching",
    description:
      "CTET, UGC NET, KVS, NVS, State TETs — Central & State Teacher Eligibility Tests and Assistant Professor exams.",
    icon: "GraduationCap",
    color: "from-violet-600 to-purple-600",
    accent: "#6d28d9",
  },
  {
    id: "police",
    name: "Police",
    description:
      "SI, ASI, Constable recruitment for Central Armed Police Forces and State Police departments.",
    icon: "Siren",
    color: "from-red-600 to-rose-700",
    accent: "#b91c1c",
  },
  {
    id: "insurance",
    name: "Insurance",
    description:
      "LIC AAO/ADO, NIACL AO/Assistant, GIC, UIIC — public sector insurance company officer & assistant exams.",
    icon: "Umbrella",
    color: "from-blue-600 to-indigo-600",
    accent: "#1d4ed8",
  },
  {
    id: "statepsc",
    name: "State PSC",
    description:
      "State Public Service Commissions — State Civil Services, State Subordinate Services & State Forest exams.",
    icon: "Building2",
    color: "from-fuchsia-600 to-pink-600",
    accent: "#a21caf",
  },
  {
    id: "postal",
    name: "Postal",
    description:
      "India Post GDS, PA, SA, MTS recruitment — Gramin Dak Sevak, Postal Assistant & Sorting Assistant exams.",
    icon: "Mail",
    color: "from-lime-600 to-green-600",
    accent: "#4d7c0f",
  },
];
