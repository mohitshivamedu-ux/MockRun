import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MockPrep India · CBT Mock Tests for Government Exams",
  description:
    "Practice real-time Computer Based Test (CBT) mock tests for SSC, UPSC, Banking, Railway, Defence, Teaching, Police, Insurance, State PSC & Postal exams — with authentic patterns, prescribed timers and detailed solutions.",
  keywords: [
    "SSC CGL mock test",
    "UPSC Civil Services mock test",
    "IBPS PO mock test",
    "RRB NTPC mock test",
    "CDS mock test",
    "NDA mock test",
    "CTET mock test",
    "LIC AAO mock test",
    "India government exam mock tests",
    "CBT practice tests India",
  ],
  authors: [{ name: "MockPrep India" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "MockPrep India · CBT Mock Tests for Government Exams",
    description:
      "Practice real-time CBT mocks for SSC, UPSC, Banking, Railway, Defence, Teaching, Police, Insurance, State PSC & Postal exams with authentic patterns, prescribed timers and detailed solutions.",
    url: "https://chat.z.ai",
    siteName: "MockPrep India",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "MockPrep India",
    description: "CBT Mock Tests for all Indian government competitive exams",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
