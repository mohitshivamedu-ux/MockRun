"use client";

import { useTestStore } from "@/lib/test-store";
import { HomeView } from "@/components/mock-test/home-view";
import { CategoryView } from "@/components/mock-test/category-view";
import { ExamDetailView } from "@/components/mock-test/exam-detail-view";
import { TestInstructionsView } from "@/components/mock-test/test-instructions-view";
import { TestRunningView } from "@/components/mock-test/test-running-view";
import { ResultView } from "@/components/mock-test/result-view";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, ExternalLink } from "lucide-react";

export default function Home() {
  const view = useTestStore((s) => s.view);
  const navigate = useTestStore((s) => s.navigate);

  // The test-running view is a full-screen take-over (no header/footer)
  if (view === "test-running") {
    return <TestRunningView />;
  }

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <main className="flex-1">
        {view === "home" && <HomeView />}
        {view === "category" && <CategoryView />}
        {view === "exam" && <ExamDetailView />}
        {view === "test-instructions" && <TestInstructionsView />}
        {view === "result" && <ResultView />}
      </main>

      {/* Footer — sticky at bottom */}
      <footer className="mt-auto border-t border-slate-200 bg-slate-900 text-slate-300">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <div className="sm:col-span-2 lg:col-span-1">
              <button
                onClick={() => navigate("home")}
                className="flex items-center gap-2 text-left"
              >
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500 text-white">
                  <GraduationCap className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-base font-bold text-white">MockPrep India</div>
                  <div className="text-xs text-slate-400">CBT Mock Tests for Government Exams</div>
                </div>
              </button>
              <p className="mt-3 text-xs leading-5 text-slate-400">
                A comprehensive platform for aspirants of SSC, UPSC, Banking, Railway, Defence,
                Teaching, Police, Insurance, State PSC &amp; Postal exams — practice authentic
                Computer Based Tests with live timers and detailed solutions.
              </p>
            </div>

            <FooterLinkGroup
              title="Exam Categories"
              links={[
                { label: "SSC", onClick: () => navigate("category", { categoryId: "ssc" }) },
                { label: "UPSC", onClick: () => navigate("category", { categoryId: "upsc" }) },
                { label: "Banking", onClick: () => navigate("category", { categoryId: "banking" }) },
                { label: "Railway", onClick: () => navigate("category", { categoryId: "railway" }) },
                { label: "Defence", onClick: () => navigate("category", { categoryId: "defence" }) },
              ]}
            />

            <FooterLinkGroup
              title="More Categories"
              links={[
                { label: "Teaching", onClick: () => navigate("category", { categoryId: "teaching" }) },
                { label: "Police", onClick: () => navigate("category", { categoryId: "police" }) },
                { label: "Insurance", onClick: () => navigate("category", { categoryId: "insurance" }) },
                { label: "State PSC", onClick: () => navigate("category", { categoryId: "statepsc" }) },
                { label: "Postal", onClick: () => navigate("category", { categoryId: "postal" }) },
              ]}
            />

            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">Disclaimer</h3>
              <p className="mt-2 text-xs leading-5 text-slate-400">
                Mock tests on this platform are practice tests designed to mirror the pattern,
                timer and marking scheme of the original examinations. They are not affiliated
                with or endorsed by the conducting bodies (SSC, UPSC, IBPS, RBI, RRB, LIC, etc.).
                Refer to official notifications for accurate exam details.
              </p>
            </div>
          </div>

          <div className="mt-6 flex flex-col items-center justify-between gap-2 border-t border-slate-700 pt-4 text-xs text-slate-400 sm:flex-row">
            <div>© {new Date().getFullYear()} MockPrep India · Built for aspirants, by aspirants.</div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-slate-600 text-slate-300">v1.0</Badge>
              <span className="text-slate-500">Made in India</span>
            </div>
          </div>

          {/* Powered by — clickable, opens in new tab */}
          <div className="mt-4 flex flex-col items-center gap-1 border-t border-slate-700 pt-4 text-center sm:flex-row sm:justify-center sm:gap-2">
            <span className="text-xs text-slate-400">Powered by</span>
            <a
              href="https://www.theprojectwala.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-sm font-semibold text-emerald-400 transition-all hover:bg-emerald-500/10 hover:text-emerald-300"
              aria-label="Visit The Project Wala website (opens in a new tab)"
            >
              <span className="bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent transition-all group-hover:from-emerald-300 group-hover:to-teal-200">
                The Project Wala
              </span>
              <ExternalLink className="h-3.5 w-3.5 text-emerald-500/70 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function FooterLinkGroup({ title, links }: { title: string; links: { label: string; onClick: () => void }[] }) {
  return (
    <div>
      <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-200">{title}</h3>
      <ul className="mt-2 space-y-1.5">
        {links.map((link) => (
          <li key={link.label}>
            <button
              onClick={link.onClick}
              className="text-xs text-slate-400 hover:text-emerald-400 hover:underline"
            >
              {link.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
